import { Component, EventEmitter, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { keywords, toastrMsg } from 'src/app/shared/constant';
import ContextMenu from "devextreme/ui/context_menu";
import { ActivatedRoute, Router } from '@angular/router';
import { ApiPaths, decryptUsingAES256 } from 'src/app/shared/util';
import { RestApiService } from 'src/app/services/rest-api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogService } from 'src/app/components/confirmation-dialog/confirmation-dialog.service';
import { StoreService } from 'src/app/services/store.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal'
import { template } from 'lodash';
import { DxDataGridComponent, DxTooltipComponent } from 'devextreme-angular';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ReviewService } from '../review-invoice-modal/review.service';
import { InvoiceService } from '../../invoice-details/invoice.service';
import { AuthenticationService } from 'src/app/_services';
import autoTable from 'jspdf-autotable';
import jsPDF from 'jspdf';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
@Component({
  selector: 'data-grid',
  templateUrl: './datagrid.component.html',
  styleUrls: ['./datagrid.component.scss']
})
export class DataGridComponent {
  @Input() dataSource;
  @Input() gridHeader;
  @Input() reviewInvoicePageInfo;
  @Input() showNoRecords;
  @Input() newRecord;
  @Input() pageConfig;
  @Input() params;
  @ViewChild(DxTooltipComponent) tooltip: DxTooltipComponent;
  @ViewChild('approveInvoice') approveInvoice: TemplateRef<any>;
  @ViewChild('rejectInvoice') rejectInvoice: TemplateRef<any>;
  @ViewChild('passwordTemplate') passwordTemplate: TemplateRef<any>;
  @Output() getFilter = new EventEmitter();
  @Output() getParams = new EventEmitter();
  @Output() getReviewHistory = new EventEmitter();

  @ViewChild(DxDataGridComponent, {
    static: false
  }) dataGrid: DxDataGridComponent;
  header: any;
  columns = [];
  actionClick: Function;
  editClick: Function;
  editTravelRequest: Function;
  deleteRow: Function;
  editDropDownMenu: any;
  menuInstance;
  pageId: any;
  modalRef?: BsModalRef;
  focusedRowKey;
  focus: boolean = false
  reqCreatedDate: any
  date: any = new Date()
  highlight: boolean = false;
  viewInvoice: Function;
  password: any;
  userDetails;
  optionsData;
  primaryKey: any;
  filterData: any;
  empAddress: any;
  generatePdfDetailsList: any = [];
  amountInWords: any;
  totalAmount = 0;
  constructor(private router: Router, private activeRoute: ActivatedRoute, private service: RestApiService, private lodder: LoaderService, private toastr: ToastrService, private confirmationDialogService: ConfirmationDialogService, private modalService: BsModalService, private store: StoreService, private datepipe: DatePipe, private reviewService: ReviewService, private invoiceService: InvoiceService,
    private auth: AuthenticationService, private _decimalPipe: DecimalPipe) {
    this.viewCellTemplate = this.viewCellTemplate.bind(this)
    this.approveCellTemplate = this.approveCellTemplate.bind(this)
    this.rejectCellTemplate = this.rejectCellTemplate.bind(this)
    this.editCellTemplate = this.editCellTemplate.bind(this)
    this.actionCellTemplate = this.actionCellTemplate.bind(this);
    this.viewAccountCellTemplate = this.viewAccountCellTemplate.bind(this)

    this.onClick = this.onClick.bind(this);
    // this.viewInvoice=(data)=> this.viewReview(data);
    this.auth.currentUser.subscribe(d => {
      this.userDetails = d?.loginUserDetails;
    })
    invoiceService.viewHistory.subscribe(v => this.filterData = v);
  }

  demo = []

  ngOnInit() {
    this.header = this.reviewInvoicePageInfo == undefined ? keywords.empBakHead : this.reviewInvoicePageInfo.pageName == 'reviewinvoice' ? keywords.invoiceReview : this.reviewInvoicePageInfo.pageName == 'invoicehistory' ? keywords.invoiceHistory : '';

    // setTimeout(() => {
    this.columns = [];

    this.setColoumns();
    // }, 10);
    // this.activeRoute.queryParams.subscribe(data=> this.pageId = data.pageId);
  }

  setColoumns() {

    this.header.filter((filter: any) => {


      this.columns.push({ dataField: filter.id, alignment: 'left', caption: filter.name, adaptive: true })

    })

    if (this.reviewInvoicePageInfo?.pageName == 'reviewinvoice') {
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.viewAccountCellTemplate });
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.viewCellTemplate });
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.approveCellTemplate })
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.rejectCellTemplate })
    } else if (this.reviewInvoicePageInfo?.pageName == 'invoicehistory') {
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.viewAccountCellTemplate });
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.viewCellTemplate });
      this.columns.push({ dataField: '', caption: '', adative: true, cellTemplate: this.editCellTemplate });
    } else if (this.reviewInvoicePageInfo == undefined) {
      this.primaryKey = 'empId'
      this.columns.unshift({ dataField: '', caption: "", cssClass: keywords.plusIcon, allowSorting: false, cellTemplate: this.actionCellTemplate })
    }
  }

  approveData: any
  approver: boolean = false
  rejectFlag: boolean = false
  approveCellTemplate(container, options) {
    let div = document.createElement('div');
    options.data?.invoiceObj?.reviewer01Status == "Approved" && options.data?.invoiceObj?.reviewer02Status == "Approved" ? div.classList.add('disabled-access') : (options.data?.invoiceObj?.reviewer01Status == "Approved" || options.data?.invoiceObj?.reviewer01Status == "Rejected") && this.userDetails.roleName == 'Manager' ? div.classList.add('disabled-access') : options.data?.invoiceObj?.invoiceStatus == 'Rejected' ? div.classList.add('disabled-access') : div;
    let a = document.createElement('a');
    a.classList.add('color-blue')
    // if((options.data?.invoiceObj?.reviewer01Id == null && this.userDetails.roleName != 'HR' && this.userDetails.roleName != 'Finanace') || (options.data?.invoiceObj?.reviewer01Id != null && this.userDetails.roleName == 'HR')){
    let html = '<i class="fa fa-check" style="color: #81d302;font-size: 20px;"></i>'
    a.innerHTML = html;
    a.onclick = () => {
      this.template(this.approveInvoice)
      this.approveData = options.data?.invoiceObj;

    }
    // }else{
    //   let html = '<i class="fa fa-check" style="color: gray;font-size: 20px;"></i>'
    //   a.innerHTML = html;
    // }

    div.append(a);
    return div;
  }

  rejectData: any;
  comment: any;

  rejectCellTemplate(container, options) {
    let div = document.createElement('div');
    options.data?.invoiceObj?.reviewer01Status == "Approved" && options.data?.invoiceObj?.reviewer02Status == "Approved" ? div.classList.add('disabled-access') : (options.data?.invoiceObj?.reviewer01Status == "Approved" || options.data?.invoiceObj?.reviewer01Status == "Rejected") && this.userDetails.roleName == 'Manager' ? div.classList.add('disabled-access') : options.data?.invoiceObj?.invoiceStatus == 'Rejected' ? div.classList.add('disabled-access') : div;
    let a = document.createElement('a');
    a.classList.add('color-blue')
    // if(this.approver == false){
    let html = '<i class="fa fa-close" style="color: red;font-size: 20px;"></i>'
    a.innerHTML = html;
    a.onclick = () => {
      this.template(this.rejectInvoice);
      this.approveData = options.data?.invoiceObj;
      options.key.status = "Rejected"
      this.rejectFlag = true
      this.approver = false
      //  options.key.comment=this.comment
      this.rejectData = options.data?.invoiceObj

      //this.applyFiltersEvent.emit(options);
    }
    // }else{
    //   let html = '<i class="fa fa-close" style="color: gray;font-size: 20px;"></i>'
    //   a.innerHTML = html;
    // }


    div.append(a);
    return div;
  }

  actionCellTemplate(container, options) {
    let div = document.createElement('div')
    let a = document.createElement('a');
    a.classList.add('color-blue')
    let html = '<button type=button class="btn btn-primary" style="background: #2A235F; height: 35px;">View History</button>'

    if (this.dataGrid.instance.isRowExpanded(options.key)) {
      html = '<button type=button class="btn btn-primary" style="background: #2A235F; height: 35px;">Hide History</button>'
    }
    a.innerHTML = html;
    a.onclick = () => {
      if (this.dataGrid.instance.isRowExpanded(options.key)) {
        this.dataGrid.instance.collapseRow(options.key)
      } else {
        options.component.collapseAll(-1)
        this.dataGrid.instance.expandRow(options.key)
      }
    }
    div.append(a);
    return div;
  }


  template(template: TemplateRef<any>) {
    this.password = null
    this.modalRef = this.modalService.show(template);

  }

  approve() {
    //  this.rejectData.status='Approved'
    if (this.userDetails?.roleName == 'Manager') {
      this.approveData.reviewer01Id = this.userDetails?.empId;
      this.approveData.reviewer01PrcDt = new Date();
      this.approveData.reviewer01Status = "Approved";
      this.approveData.reviewer01Comments = "-"
      this.approveData.invoiceStatus = "Pending";
      // this.approveData.reportingId = this.userDetails.hrId;
    } else if (this.userDetails?.roleName == 'HR' && this.approveData.reviewer01Id != null) {
      this.approveData.reviewer02Id = this.userDetails?.empId;
      this.approveData.reviewer02PrcDt = new Date();
      this.approveData.reviewer02Status = "Approved";
      this.approveData.reviewer02Comments = "-";
      this.approveData.invoiceStatus = "Approved";
      // this.approveData.reportingId = this.userDetails.financeId;
    } else if (this.userDetails?.roleName == 'HR' && this.approveData.reviewer01Id == null) {
      this.approveData.reviewer02Id = this.userDetails?.empId;
      this.approveData.reviewer02PrcDt = new Date();
      this.approveData.reviewer02Status = "Approved";
      this.approveData.reviewer02Comments = "-";
      this.approveData.invoiceStatus = "Approved";
      this.approveData.reviewer01Id = this.userDetails?.empId;
      this.approveData.reviewer01PrcDt = new Date();
      this.approveData.reviewer01Status = "Approved";
      this.approveData.reviewer01Comments = "-"
      this.approveData.invoiceStatus = "Approved";
      // this.approveData.reportingId = this.userDetails.financeId;
    }

    let date = new Date();
    // let month = date.getMonth() + +1
    let month = this.approveData.invoiceYear

    this.service.saveData('saveOrUpdateinvoice', this.approveData).subscribe(d => {
      if (this.filterData?.url == 'getEmpInvReviewHistory/') {
        // this.getParams.emit(null)
        // let url = 'getEmpInvReviewHistory/'+this.filterData?.roleName +'/'+this.filterData?.reportingId + '/' + this.filterData?.empId +'/' + this.filterData?.month + '/' + this.filterData?.status;
        // this.getFilter.emit(url)
        delete this.filterData.url
        this.getReviewHistory.emit(this.filterData)
      } else if (this.filterData?.url == 'getInvoiceByReportingId/') {
        let url = 'getInvoiceByReportingId/' + this.filterData?.roleName + '/' + this.filterData?.reportingId + '/' + this.filterData?.month;
        this.getParams.emit(null)
        this.getFilter.emit(url)
      } else if (this.filterData?.url == 'getInvoiceByInvoiceNo/') {
        let params = { invNum: this.filterData?.invNum, month: this.filterData?.month };
        let url = 'getInvoiceByInvoiceNo';
        this.getParams.emit(params)
        this.getFilter.emit(url)
      }
    })


    this.toastr.success('Invoice Sheet has been successfully approved');

  }

  reject() {
    if (this.userDetails?.roleName == 'Manager') {
      this.rejectData.reviewer01Id = this.userDetails?.empId;
      this.rejectData.reviewer01PrcDt = new Date();
      this.rejectData.reviewer01Status = "Rejected";
      this.rejectData.reviewer01Comments = this.comment;
      this.rejectData.invoiceStatus = "Rejected";
      //this.rejectData.reportingId = null;
    } else if (this.userDetails?.roleName == 'HR' && this.approveData.reviewer01Id != null && this.approveData.reviewer01Status == 'Approved') {
      this.rejectData.reviewer02Id = this.rejectData.hrId;
      this.rejectData.reviewer02PrcDt = this.datepipe.transform(new Date(), keywords.formateDateOnly);
      this.rejectData.reviewer02Status = "Rejected";
      this.rejectData.reviewer02Comments = this.comment;
      this.rejectData.invoiceStatus = "Rejected";
      //this.approveData.reportingId = null;
    } else if (this.userDetails?.roleName == 'HR' && this.approveData.reviewer01Id == null) {
      this.rejectData.reviewer02Id = this.rejectData.hrId;
      this.rejectData.reviewer02PrcDt = this.datepipe.transform(new Date(), keywords.formateDateOnly);
      this.rejectData.reviewer02Status = "Rejected";
      this.rejectData.reviewer02Comments = this.comment;
      this.rejectData.invoiceStatus = "Rejected";
      this.rejectData.reviewer01Id = this.userDetails?.empId;
      this.rejectData.reviewer01PrcDt = new Date();
      this.rejectData.reviewer01Status = "Rejected";
      this.rejectData.reviewer01Comments = this.comment;
      this.rejectData.invoiceStatus = "Rejected";
      //this.approveData.reportingId = null;
    }

    let date = new Date();
    //let month = date.getMonth() + +1
    let month = this.rejectData.invoiceYear
    this.service.saveData('saveOrUpdateinvoice', this.approveData).subscribe(d => {
      if (this.filterData?.url == 'getEmpInvReviewHistory/') {
        // this.getParams.emit(null)
        // let url = 'getEmpInvReviewHistory/'+this.filterData?.roleName +'/'+this.filterData?.reportingId + '/' + this.filterData?.empId +'/' + this.filterData?.month + '/' + this.filterData?.status;
        // this.getFilter.emit(url)
        delete this.filterData.url
        this.getReviewHistory.emit(this.filterData)
      } else if (this.filterData?.url == 'getInvoiceByReportingId/') {
        let url = 'getInvoiceByReportingId/' + this.filterData?.roleName + '/' + this.filterData?.reportingId + '/' + this.filterData?.month;
        this.getParams.emit(null)
        this.getFilter.emit(url)
      } else if (this.filterData?.url == 'getInvoiceByInvoiceNo/') {
        let params = { invNum: this.filterData?.invNum, month: this.filterData?.month };
        let url = 'getInvoiceByInvoiceNo';
        this.getParams.emit(params)
        this.getFilter.emit(url)
      }
    })

    // this.service.saveData('saveOrUpdateinvoice',this.rejectData).subscribe(d =>this.getFilter.emit('getInvoiceByReportingId/' + this.userDetails.roleName + '/' + this.userDetails.empId+'/'+ month))


    this.toastr.success('Invoice Sheet has been rejected');
    //this.rejectData.comment=this.comment
    // this.rejectData.status='Rejected'
  }


  viewCellTemplate(container, options) {
    let div = document.createElement('div');
    let a = document.createElement('a');
    a.classList.add('color-blue')
    let html = '<i class="fas fa-file-invoice"></i>'
    a.innerHTML = html;
    a.onclick = (e) => {
      // this.reviewService.getDataource('view')

      this.template(this.passwordTemplate);
      this.optionsData = options;
      //this.onViewReview(options)


      //this.reviewService.getDataource('view')
    }
    div.append(a);
    return div;
  }

  viewAccountCellTemplate(container, options) {
    let div = document.createElement('div');
    let a = document.createElement('a');
    a.classList.add('color-blue')
    let html = '<i class="fa fa-bank"></i>'
    a.innerHTML = html;
    a.onclick = (e) => {
      // this.reviewService.getDataource('view')
      //this.service.getOrDeleteData('getBankDetails/'+  options.data.invoiceObj.empId + '/' + 'active',null).subscribe(d => this.bankDetails = d)
      this.template(this.passwordTemplate);
      this.optionsData = options;
      //this.onViewReview(options)


      //this.reviewService.getDataource('view')
    }
    div.append(a);
    return div;
  }
  onViewReview(data: any) {
    this.lodder.show()
    setTimeout(() => {
      if (this.reviewInvoicePageInfo?.pageName == 'reviewinvoice') {
        this.lodder.hide()
        if (this.password == this.userDetails.empId && this.optionsData.columnIndex == 11) {
          this.service.getOrDeleteData('getAddress/' + this.optionsData.data.invoiceObj.empId, null).subscribe(o => {
            this.optionsData.data.employee = o
            this.reviewService.open(this.optionsData.data, this.pageConfig, this.reviewInvoicePageInfo?.pageName, 'invoice');
          })

        } else if (this.password == this.userDetails.empId && this.optionsData.columnIndex == 10) {
          this.service.getOrDeleteData('getBankDetails/' + this.optionsData.data.invoiceObj.empId + '/' + 'active', null).subscribe(d => {
            if (d != null || d?.length > 0) {
              this.reviewService.open(d, this.pageConfig, this.reviewInvoicePageInfo?.pageName, 'bank')
            }
          })
        }
        else {
          this.toastr.error("Password is incorrect")
        }
      } else if (this.reviewInvoicePageInfo.pageName == 'invoicehistory') {
        this.lodder.hide()
        if (this.password == decryptUsingAES256(this.pageConfig.employee?.empPassword) && this.optionsData.columnIndex == 10) {
          this.service.getOrDeleteData('getBankDetails/' + this.optionsData.data.invoiceObj.empId + '/' + 'active', null).subscribe(d => {
            if (d != null || d.length > 0) {
              this.reviewService.open(d, this.pageConfig, this.reviewInvoicePageInfo?.pageName, 'bank')
            }
          })
          // this.reviewService.open(this.optionsData.data,this.pageConfig,this.reviewInvoicePageInfo.pageName,'invoice')
        } else if (this.password == decryptUsingAES256(this.pageConfig.employee?.empPassword) && this.optionsData.columnIndex == 11) {
          this.service.getOrDeleteData('getAddress/' + this.optionsData.data.invoiceObj.empId, null).subscribe(o => {
            this.optionsData.data.employee = o
            this.reviewService.open(this.optionsData.data, this.pageConfig, this.reviewInvoicePageInfo?.pageName, 'invoice');
          })
          //this.reviewService.open(this.optionsData.data,this.pageConfig,this.reviewInvoicePageInfo?.pageName,'invoice')
        } else {
          this.toastr.error("Password is incorrect")
        }
      }
    }, 3000)

  }


  onClick(e) {

  }

  editCellTemplate(container, options) {
    let div = document.createElement('div');
    if (this.reviewInvoicePageInfo.pageName == 'reviewinvoice') {
      options.data?.invoiceObj?.reviewer01Status == "Approved" && options.data?.invoiceObj?.reviewer02Status == "Approved" ? div.classList.add('disabled-access') : options.data?.invoiceObj?.status == 'inactive' ? div.classList.add('disabled-access') : (options.data?.invoiceObj?.reviewer01Status == "Approved" || options.data?.invoiceObj?.reviewer01Status == "Rejected") && this.userDetails?.roleName == 'Manager' ? div.classList.add('disabled-access') : div;
    } else {
      options.data?.invoiceObj?.invoiceStatus == 'Approved' ? div.classList.add('disabled-access') : div;
    }
    let a = document.createElement('a');
    a.classList.add('color-blue')
    let html = '<i class="fa fa-edit"></i>'
    a.innerHTML = html;
    a.onclick = () => {
      this.onEdit(options)
    }
    div.append(a);
    return div;
  }

  onEdit(data: any) {
    let dataCopy = data?.data;

    let projects = dataCopy.invoiceObj.cpdId.includes(',') ? dataCopy.invoiceObj.cpdId.split(',') : [dataCopy.invoiceObj.cpdId]
    let clients = dataCopy.invoiceObj.clientId.includes(',') ? dataCopy.invoiceObj.clientId.split(',') : [dataCopy.invoiceObj.clientId];

    let expenses = [];
    let deduction = [];
    if (dataCopy?.particularEntity.length > 0) {
      dataCopy?.particularEntity?.forEach(par => {
        if (par.particularType == "deduction") {
          let date = par?.deductionDate.split(',')
          date.forEach((d, index) => {
            date[index] = new Date(d)
          })
          let deduct = {
            particularId: par?.particularId,
            name: par?.name,
            amount: isNaN(par?.amount) ? decryptUsingAES256(par?.amount) : par?.amount,
            noOfDays: +par?.noOfDays,
            others: '',
            hours: 0,
            dates: date,
            comment: par.comment,
            particularType: 'deduction'
          }
          deduction.push(deduct);

        }
        else if (par.particularType == "expenses") {
          let part = {
            particularId: par?.particularId,
            name: par?.name,
            amount: isNaN(par?.amount) ? decryptUsingAES256(par?.amount) : par?.amount,
            attachment: [],
            others: par.others,
            hours: par.hours,
            noOfDays: +par.noOfDays
          }
          dataCopy?.particularFileEntity?.forEach(file => {
            if (file.particularId == par.particularId) {
              part.attachment.push(file)
            }
          });
          expenses.push(part);
        }
      })
    }
    if (deduction.length == 0) {
      let deduct = {
        particularId: null,
        name: '',
        amount: 0,
        noOfDays: 0,
        others: '',
        hours: 0,
        dates: [],
        comment: '',
        particularType: 'deduction'
      }
      deduction.push(deduct);
    } else if (expenses.length == 0) {
      let part = {
        particularId: null,
        name: '',
        amount: 0,
        attachment: [],
        others: null,
        hours: 0,
        noOfDays: 0
      }
      expenses.push(part);
    }
    let year = dataCopy?.invoiceObj.invNum.substr(3, 4)
    let date = this.datepipe.transform(new Date(year + '-' + dataCopy?.invoiceObj?.invoiceMonth + '-' + '1'), 'EEEE, MMMM d, y, h:mm:ss a zzzz')
    const invoiceDetails = {
      invId: dataCopy?.invoiceObj?.invId,
      consultantName: dataCopy?.invoiceObj.consultantName,
      reportingManagerName: dataCopy?.invoiceObj.reportingManagerName,
      projectId: projects,
      clientId: clients,
      submissionDate: new Date(dataCopy?.invoiceObj.submissionDate),
      submissionMonth: date,
      invoiceNo: dataCopy?.invoiceObj.invNum,
      particulars: dataCopy?.invoiceObj?.particulars,
      noOfDays: dataCopy?.invoiceObj.noOfDays,
      invAmount: isNaN(dataCopy?.invoiceObj.invAmount) ? decryptUsingAES256(dataCopy?.invoiceObj.invAmount) : dataCopy?.invoiceObj.invAmount,
      invoiceMonth: dataCopy?.invoiceObj?.invoiceMonth,
      invoiceYear: dataCopy?.invoiceObj?.invoiceYear,
      totalAmt: '',
      effectiveFromDate: this.pageConfig?.compensation?.effectiveFromDate,
      effectiveToDate: this.pageConfig?.compensation?.effectiveToDate,
      invoiceStatus: dataCopy?.invoiceObj?.invoiceStatus,
      reviewer01Status: dataCopy?.invoiceObj?.reviewer01Status,
      reviewer02Status: dataCopy?.invoiceObj?.reviewer02Status,
      reportingId: dataCopy?.invoiceObj.reportingId,
      expenses: expenses,
      deductions: deduction,
      attendenceDetails: dataCopy?.attendenceEntity
    }

    //this.store.gridRowData.next(data.data)
    this.invoiceService.reset('edit')
    this.invoiceService.setdocument(invoiceDetails);
    this.store.gridRowData.next(dataCopy?.attendenceEntity)
    this.router.navigate(['/dwc/inv/createinvoice'])

  }

  modalHide() {
    this.modalService.hide()
  }

  pdfdownload() {
    let userPassword = '';
    let ownerPassword = ''
    if (this.reviewService.pageName == 'reviewinvoice') {
      // userPassword = this.userData.empId
      // ownerPassword = this.userData.empId
    } else if (this.reviewService.pageName == 'invoicehistory') {
      userPassword = decryptUsingAES256(this.pageConfig?.employee?.empPassword);
      ownerPassword = decryptUsingAES256(this.pageConfig?.employee?.empPassword);
    }
    const doc = new jsPDF({
      encryption: {
        userPassword: userPassword,
        ownerPassword: ownerPassword,
        userPermissions: ["print", "modify", "copy", "annot-forms"]
      }
    });
    // new jsPDF('p','mm','a4')
    for (let i = 0; i < this.dataSource.length; i++) {
      this.generatePdfDetailsList = this.dataSource[i];
      console.log("invoiceObj", this.generatePdfDetailsList.invoiceObj.invAmount)
      this.generatePdfDetailsList.invoiceObj.invAmount = decryptUsingAES256(this.generatePdfDetailsList.invoiceObj.invAmount)
      this.generatePdfDetailsList.particularEntity.forEach((f, index) => {
        this.generatePdfDetailsList.particularEntity[index].amount = decryptUsingAES256(this.generatePdfDetailsList.particularEntity[index].amount)
      })
      let body = []
      let finlaLIst: any = []
      var tittle = 'Invoice'
      var summary = 'Consultant Details'
      var bankDetails = 'Bank Details';
      var details = 'Invoice Details'
      var status = 'Status :'
      let lengthOfIndex = 0;
      var invStatus = this.generatePdfDetailsList.invoiceObj.invoiceStatus
      var color = this.generatePdfDetailsList.invoiceObj.invoiceStatus == 'Approved' ? 'green' : this.generatePdfDetailsList.invoiceObj.invoiceStatus == 'Rejected' ? 'red' : 'orange'
      //  if(this.selectedLang == 'en'){

      finlaLIst.push([this.generatePdfDetailsList.invoiceObj.particulars, this.generatePdfDetailsList.invoiceObj.noOfDays, this.generatePdfDetailsList.invoiceObj.invAmount])
      this.generatePdfDetailsList.particularEntity.forEach(element => {
        body = []
        let part = ''
        if (element.name == 'Overtime') {
          part = element.name + " (" + element.hours + ' hrs)'
        } else if (element.name == 'Others') {
          part = element.name + " (" + element.others + ' )'
        } else if (element.name == 'Offshore Unpaid Leave') {
          part = element.name + " (" + element.comment + ')'
        } else if (element.name == 'Onsite Unpaid Leave') {
          part = element.name + " (" + element.comment + ')'
        } else if (element.name == 'Offshore') {
          part = element.comment
        } else if (element.name == 'Onsite') {
          part = element.comment
        } else if (element.name != '') {
          part = element.name
        }
        let amount = element.name == 'Offshore Unpaid Leave' || element.name == 'Onsite Unpaid Leave' ? '- ' + element?.amount : element.amount;
        body.push(part, element.noOfDays, element.amount)
        finlaLIst.push(body)
      });
      this.sumOfIncome(this.generatePdfDetailsList);
      finlaLIst.push([this.amountInWords, 'Total Amount:', this.totalAmount])
      console.log("AMOUT of words", finlaLIst)
      finlaLIst.forEach(e => {
        console.log("e", e)
        let minus = e[0].includes('Unpaid') ? '-' + e[2] : e[2];
        let num = this._decimalPipe.transform(e[2], '1.2-2');
        num = e[0].includes('Unpaid') ? '- ' + num : num;
        e[2] = num
      })
      lengthOfIndex = finlaLIst.length - 1;
      let addr = ''
      // for (let i = 0; i < this.generatePdfDetailsList.employee.address.length; i++) {
      //   if (i == 35) {
      //     addr = addr + '\n'
      //   } else if (i == 70) {
      //     addr = addr + '\n'
      //   } else {
      //     addr = addr + this.generatePdfDetailsList.employee.address.charAt(i)
      //   }

      // }
      if (tittle) {
        doc.setFontSize(24),
          doc.setFont('helvetica', 'bold'),
          doc.setFillColor('#113132')
        doc.rect(0, 0, 210, 45, 'F')
        doc.setTextColor('white');
        doc.text(tittle, 5, 38),

          doc.setFontSize(10),
          doc.setFont('helvetica'),
          doc.setTextColor('gray');
        // doc.text('Invoice :',160 ,15)

        // doc.setFontSize(10),
        // doc.setFont('helvetica'),
        // doc.setTextColor('white');
        // doc.text(this.date,185 ,15)

        // doc.addImage(imgData, 5, 5, 80, 20);
      }

      if (status) {
        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(status, 100, 60)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor(color);
        doc.text(invStatus, 130, 60)

      }
      if (summary) {
        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(summary, 5, 60)

        doc.setDrawColor('#ECEBEB');
        doc.setFillColor('#F6F8FA')
        doc.roundedRect(3, 65, 203, 70, 3, 3, 'FD');

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Consultant Name', 10, 75)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(this.generatePdfDetailsList.invoiceObj.consultantName, 10, 85)


        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Supervisor Name', 100, 75)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(this.generatePdfDetailsList.invoiceObj.reportingManagerName, 100, 85)

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Invoice Number', 10, 95)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(this.generatePdfDetailsList.invoiceObj.invNum, 10, 105)

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Clients Name', 100, 95)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(this.generatePdfDetailsList.invoiceObj.clientId, 100, 105)

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Invoice Date', 10, 115)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(this.generatePdfDetailsList.invoiceObj.submissionDate, 10, 125)

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Consultant Address', 100, 115)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(addr, 100, 125)

        doc.setFontSize(10),
          doc.setFont('helvetica', 'normal'),
          doc.setTextColor('black');
        doc.text('Bill To', 10, 135)

        doc.setFontSize(14),
          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text('Rootware Technologies DWC-LLC Dated 4/26/2024 PO Box 712738, Dubai UAE', 10, 145)
      }

      if (details) {
        doc.setFontSize(14),

          doc.setFont('helvetica', 'bold'),
          doc.setTextColor('black');
        doc.text(details, 5, 155)

        // doc.setFontSize(10),
        // doc.setFont('helvetica','normal'),
        // doc.setTextColor('#3498DB');
        // doc.text('['+' '+this.totalRecordsCount+' '+'records]',25 ,135)

      }
      autoTable(doc, {
        margin: { horizontal: 5 },
        bodyStyles: {},
        startY: 158,
        headStyles: {
          fillColor: 'white',
          fontStyle: 'bold',
          halign: 'left',    //'center' or 'right'   
          textColor: '#1D1556', //White     
          fontSize: 10,
        },
        styles: {
          cellPadding: 3,
          fontSize: 8,
          valign: 'middle',
          overflow: 'linebreak',
          lineWidth: 0,
        },
        //change the text style of last row
        willDrawCell: function (data) {
          var rows = data.table.body;
          if (data.row.index === rows.length - 1) {
            doc.setFont('helvetica', 'bold'),
              doc.setTextColor('black');
          }
        },
        head: [['Particulars', 'No.Of Days', 'Amount']],
        body: finlaLIst,
        showHead: "firstPage",
        alternateRowStyles: {

        },
        //align specific header column
        didParseCell: (hookData) => {
          if (hookData.section === 'head') {
            if (hookData.column.dataKey === 1) {
              hookData.cell.styles.halign = 'right';
            }
          }
        },

        columnStyles: {
          1: {
            halign: 'right',
            fontStyle: 'bold',
            textColor: 'black',
            //cellWidth: 20,
            lineColor: 'black',
          },
          2: {
            halign: 'right',
            fontStyle: 'bold',
            textColor: 'black',
            cellWidth: 20,
            lineColor: 'black',
          }
        },
        didDrawPage: function (data) {
          if (data.pageCount > 1) { }
        },
      });

      let month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      let year = new Date(this.generatePdfDetailsList.invoiceObj.submissionDate).getFullYear()
      doc.addPage()
    }
    let pdfName = 'Invoice_sheet_'
    doc.save(pdfName)
  }

  csvDownload() {
    let ids = [{ empId: 'RWTD-16', invoiceNo: 'AS=20240104' }, { empId: 'RWI-15004', invoiceNo: 'AN=20240104' }]
    let empIds = { empId: "RWTD-16,RWI-15004,19094" };
    let excelArray = [];
    let excelObj = { srno: 0, accountHolderName: '', bankName: '', bankAddress: '', ifsc: '', accountNumber: '', currency: '', inrAmount: '', rate: '', aedAmount: '', alAnsari: 23, totalAed: '', country: '' }
    let bankAndComp;

    this.service.saveData(ApiPaths.getcompAndBankDetails, empIds).subscribe(o => { bankAndComp = o });
    setTimeout(() => {
      let invoiceData = [];
      let bank = [];
      this.dataSource.map(m => {
        ids.filter(f => {
          bankAndComp.filter(a => a.bank.empId == f.empId ? bank.push(a) : '')
          bank = this.removeDuplicates(bank);
          if (m.invoiceObj.empId == f.empId && m.invoiceObj.invNum == f.invoiceNo) {
            let index = bank.findIndex(i => i.bank.empId == f.empId)
            index > -1 ? bank[index]["invoice"] = m.invoiceObj : '';
            invoiceData.push(m.invoiceObj)
          }
        })
      })

      console.log("bank", bank)
      bank.forEach((f, i) => {
        let amount = decryptUsingAES256(f.invoice.invAmount)
        excelObj.srno = i;
        excelObj.accountHolderName = f.bank.accountHolderName;
        excelObj.bankName = f.bank.bankName;
        excelObj.bankAddress = f.bank.bankAddress;
        excelObj.ifsc = f.bank.ifscCode;
        excelObj.accountNumber = f.bank.accountNumber;
        excelObj.currency = f.currency;
        excelObj.inrAmount = f.currency == 'SAR ( ر.س)' ? (+amount * 0.98) : amount;
        excelObj.rate = f.bank.rate;
        excelObj.aedAmount = f.bank.aedAmount;
        excelObj.alAnsari = 23;
        excelObj.totalAed = f.bank.totalAed;
        excelObj.country = f.currency == 'INR (₹)' ? 'India' : f.currency == 'SAR ( ر.س)' ? 'Saudi' : '-';
        excelArray.push(excelObj)
      })

      const header = [
        'S.NO',
        'BENEFICIARY NAME ',
        'BENEFICIARY BANK',
        'BENEFICIARY BRANCH',
        'IFSC',
        'BENEFICIARY ACCOUNT NUMBER',
        'CURRENCY',
        'AMOUNT',
        'RATE',
        'AMOUNT AED',
        'Al Ansari Service charges',
        'TOTAL AED',
        'COUNTRY '
      ];

      // Create workbook and worksheet
      const workbook = new Workbook();
      const worksheet = workbook.addWorksheet('Sharing Data');

      // Add Row and formatting
      const titleRow = worksheet.addRow(["Salary Invoice"]);
      titleRow.font = {
        name: 'Corbel',
        family: 4,
        size: 16,
        bold: true,
      };
      worksheet.getCell('A1').alignment = { vertical: 'middle', horizontal: 'center' };
      worksheet.addRow([]);
      worksheet.addRow([]);
      worksheet.mergeCells('A1:M1');
      // Add Header Row
      const headerRow = worksheet.addRow(header);

      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFFFFF' },
          bgColor: { argb: 'FFFFFF' },
        };
        cell.border = {
          top: { style: 'medium' },
          left: { style: 'medium' },
          bottom: { style: 'medium' },
          right: { style: 'medium' },
        };
      });

      excelArray.forEach((d,i) => {
        const row = worksheet.addRow(Object.values(d));
      })

      //set the width of the cell
      for(let i = 2 ; i < 12 ; i++){
        worksheet.getColumn(i).width = 30;
      }
     worksheet.getColumn(8).numFmt = '_("$"* #,##0.00_);_("$"* (#,##0.00);_("$"* "-"??_);_(@_)';

      worksheet.addRow([]);
      // Generate Excel File with given name
      workbook.xlsx.writeBuffer().then((data: any) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        fs.saveAs(blob, 'SocialShare.xlsx');
      });
      console.log("row", worksheet)
    }, 1500)

  }

  sumOfIncome(data) {
    const numWords = require('num-words')
    let expenses = data.particularEntity.filter(f => f.particularType == "expenses");
    let deductions = data.particularEntity.filter(f => f.particularType == "deduction");
    let addrow = deductions.map(t => t.name == 'Offshore' || t.name == 'Onsite' ? t.amount : '').reduce((a, b) => +a + +b, 0);
    let completeTotalOfRows = expenses.map(t => t.amount).reduce((a, b) => +a + +b, 0);
    let completeDeductOfRows = deductions.map(t => t.name == 'Offshore Unpaid Leave' || t.name == 'Onsite Unpaid Leave' ? t.amount : '').reduce((a, b) => +a + +b, 0);
    this.amountInWords = numWords(this.totalAmount = Math.round(+completeTotalOfRows + +data.invoiceObj.invAmount - +completeDeductOfRows + +addrow))
    console.log("SUMOFINCOME", completeTotalOfRows, completeDeductOfRows, data)
    this.amountInWords = this.amountInWords.charAt(0).toUpperCase() + this.amountInWords.slice(1) + ' only';
    this.totalAmount = Math.round(+completeTotalOfRows + +data.invoiceObj.invAmount - +completeDeductOfRows + +addrow);
    return this.totalAmount = Math.round(+completeTotalOfRows + +data.invoiceObj.invAmount - +completeDeductOfRows + +addrow);
  }

  removeDuplicates(arr) {
    return arr.filter((item,
      index) => arr.indexOf(item) === index);
  }
}

